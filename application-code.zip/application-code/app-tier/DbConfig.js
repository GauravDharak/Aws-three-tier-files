module.exports = Object.freeze({
    DB_HOST : 'database-1-instance-1.cv57s55yegql.us-east-1.rds.amazonaws.com',
    DB_USER : 'admin',
    DB_PWD : 'dharakgaurav',
    DB_DATABASE : 'webappdb'
});